#include<iostream>
using namespace std;
#include "mySTL/stack.h"


int main(){


return 0;
}
